package ConductorManager;
import java.util.*;

import negocio.Conductor;


public class ConductorManager {
private static List<Conductor> conductores = new ArrayList<>();
    

    public void agregarConductor(Conductor c) {
        conductores.add(c);
    }

    public Conductor buscarConductor(long id) {
        return conductores.stream().filter(c -> c.getIdConductor() == id).findFirst().orElse(null);
    }

    public void editarConductor(long id, String nuevaLicencia, String nuevoNombre ,long nuevaId) {
    	 for (int i = 0; i < conductores.size(); i++) {
    	        if (conductores.get(i).getIdConductor() == id) {
    	           
    	            Conductor actualizado = new Conductor(nuevaId, nuevoNombre, nuevaLicencia);

    
    	            conductores.set(i, actualizado);
    	            break;
    	        }
    	    }
    	}

    public void eliminarConductor(long id) {
        conductores.removeIf(c -> c.getIdConductor() == id);
    }
    public static void mostrarConductores(Scanner scanner) {
    	 if (conductores.isEmpty()) {
             System.out.println("No hay conductores registrados.");
         } else {
             System.out.println("--- Lista de Conductores ---");
             for (Conductor c : conductores) {
                 System.out.println(c);
    }
         }
    }
}
