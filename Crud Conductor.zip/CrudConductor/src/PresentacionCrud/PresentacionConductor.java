package PresentacionCrud;

import java.util.Scanner;

import ConductorManager.ConductorManager;
import negocio.Conductor;

public class PresentacionConductor {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	    ConductorManager conductorManager = new ConductorManager();
        menuConductores(scanner, conductorManager);
	}
		 public static void menuConductores(Scanner scanner, ConductorManager manager) {
			 Scanner scanner1 = new Scanner(System.in);
		        ConductorManager conductorManager = new ConductorManager();
	    	  
	        int opcion = 0;
	        boolean valido = false;
	        while (!valido) {
	        do { 
	         	 System.out.println("\n--- Menú Conductores ---");
	             System.out.println("1. Agregar");
	             System.out.println("2. Buscar");
	             System.out.println("3. Editar Licencia");
	             System.out.println("4. Eliminar");
	             System.out.println("5. Mostrar Lista");
	             System.out.println("6. Volver");
	             System.out.print("Opción: ");
	        	try {
	        
	            opcion = scanner.nextInt();
	            scanner.nextLine(); 
	            valido = true;
	        } catch (java.util.InputMismatchException e) {
	            System.out.println("Por favor ingresa un número válido.");
	            scanner.nextLine(); 
	        }
	           
	         

	            switch (opcion) {
	            
	                case 1:
	                	System.out.print("ID (10 dígitos): ");
	                   String input = "";
	                
	                	 valido = false;
	                	 long id = 0;
	                	   while (!valido) {
	                	        input = scanner.nextLine();

	                	        
	                	        if (input.matches("\\d{10}")) {
	                	            try {
	                	           id = Long.parseLong(input);
	                	                valido = true;
	                	            } catch (NumberFormatException e) {
	                	                System.out.println("El número es demasiado grande.");
	                	            }
	                	        } else {
	                	            System.out.println("Por favor ingresa exactamente 10 dígitos numericos:");
	                	        }
	                	    }
	                	 
	                    
	                    
	                    System.out.print("Nombre: ");
	                    String nombre = scanner.nextLine();
	                    while (nombre.matches(".*\\d.*")) { 
	                        System.out.println("El nombre no puede contener números. Ingresa un nombre válido:");
	                        nombre = scanner.nextLine();
	                    }
	                    String licencia = "";
	                    boolean licenciaValida = false;
	                    while (!licenciaValida) {
	                        System.out.print("Categoría Licencia (A1, A2, A3, B1, B2, B3, C1, C2, C3): ");
	                        licencia = scanner.nextLine().toUpperCase(); 

	                        if (licencia.matches("A[1-3]|B[1-3]|C[1-3]")) {
	                            licenciaValida = true;
	                        } else {
	                            System.out.println("❌ Categoría inválida. Solo se permiten: A1, A2, A3, B1, B2, B3, C1, C2, C3.");
	                        }
	                    }
	                    manager.agregarConductor(new Conductor(id, nombre, licencia));
	         
	                    break;
	                case 2:
	                   
	               
	                     long idBuscar = 0;
	                  valido = false;
	                    while (!valido) {
	                        try {System.out.print("ID a buscar: ");
	                        	  idBuscar = scanner.nextLong();
	                            Conductor c = manager.buscarConductor(idBuscar);
	                            if (c != null)
	                                System.out.println("Nombre: " + c.getNombre() + ", Licencia: " + c.getLicencia());
	                            else
	                                System.out.println("No encontrado.");
	                            scanner.nextLine(); 
	                            valido = true;
	                        } catch (java.util.InputMismatchException e) {
	                            System.out.println("Por favor ingresa un número válido.");
	                            scanner.nextLine(); 
	                        }
	                    }
	                  
	                  
	                    break;
	                case 3:
	                    
	                 long idActual = 0;
	                   valido = false;
	                    while (!valido) {
	                        try {  System.out.print("ID a buscar: ");
	                        	  idActual = scanner.nextLong();
	                        	  Conductor conductor = manager.buscarConductor(idActual);
	                        	  scanner.nextLine(); 
	                        	 
	                        	  if (conductor != null) {
	                        		  String nuevoInput;
	                        		  long nuevoId = 0;
	                        		  valido = false;
	                        		  while (!valido) {
	                        		      	 System.out.print("ID (10 dígitos): ");
	                                         nuevoInput = scanner.nextLine();
	                        			  if (!nuevoInput.matches("\\d+")) {
	                                          System.out.println(" No se permiten letras ni caracteres especiales. Solo números.");
	                                      } else if (nuevoInput.length() != 10) {
	                                          System.out.println(" El ID debe tener exactamente 10 dígitos.");
	                                      } else {
	                                          try {
	                                              nuevoId = Long.parseLong(nuevoInput);
	                                              valido = true;
	                                              
	                                          } catch (NumberFormatException e) {
	                                              System.out.println(" El número es demasiado grande para un int.");
	                                              scanner.nextLine(); 
	                                          }
	                                      }
	                                  }
	                        		  
	                        		    System.out.print("Nuevo nombre: ");
	                        		    String nuevoNombre = scanner.nextLine();
	                                    while (nuevoNombre.matches(".*\\d.*")) { 
	                                        System.out.println("El nombre no puede contener números. Ingresa un nombre válido:");
	                                        nuevoNombre = scanner.nextLine();
	                                    }
	                        		   

	                                    String nuevaLicencia = "";
	                                    boolean nuevalicenciaValida = false;
	                                    while (!nuevalicenciaValida) {
	                                        System.out.print("Categoría Licencia (A1, A2, A3, B1, B2, B3, C1, C2, C3): ");
	                                        nuevaLicencia = scanner.nextLine().toUpperCase(); 

	                                        if (nuevaLicencia.matches("A[1-3]|B[1-3]|C[1-3]")) {
	                                            nuevalicenciaValida = true;
	                                        } else {
	                                            System.out.println("❌ Categoría inválida. Solo se permiten: A1, A2, A3, B1, B2, B3, C1, C2, C3.");
	                                        }
	                                    }
	                                 

	                        		    manager.editarConductor(idActual, nuevaLicencia, nuevoNombre, nuevoId);
	                        	  }
	                        		 else {
	                        		    System.out.println(" No se encontró un conductor con ese ID.");
	                        		}
	                            valido = true;
	                            
	                        
	                        		  } catch (java.util.InputMismatchException e) {
	                            System.out.println("Por favor ingresa un número válido.");
	                            scanner.nextLine(); 
	                        }
	                    }
	              
	                    break;
	                case 4:
	                    System.out.print("ID a eliminar: ");
	                    long idDel = scanner.nextLong();
	                    manager.eliminarConductor(idDel);
	                    break;
	                case 5: 
	                	 ConductorManager.mostrarConductores(scanner);
	                	 
	                    break;
	         
	            }
	        } while (opcion != 5);
	        scanner.close();
	    }
		 
	}

}
