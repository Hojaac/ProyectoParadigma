package negocio;

public class Conductor {
	private long idConductor;
    private String nombre;
    private String licencia;

    public Conductor(long id, String nombre, String licencia) {
        this.idConductor = id;
        this.nombre = nombre;
        this.licencia = licencia;
    }

    public long getIdConductor() {
        return idConductor;
    }

    public String getNombre() {
        return nombre;
    }

    public String getLicencia() {
        return licencia;
    }

    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }


	public void setNombre(String Nombre) {
		  this.nombre = nombre;
		
	}
	public String toString() {
        return "ID: " + idConductor + " | Nombre: " + nombre + " | Licencia: " + licencia;
    }

	public void setId(long id) {
		  this.idConductor = id;
	}

}
