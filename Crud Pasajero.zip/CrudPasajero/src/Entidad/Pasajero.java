package Entidad;

public class Pasajero {
	 private long idPasajero;
	    private String nombre;


	    public Pasajero(long id, String nombre) {
	        this.idPasajero = id;
	        this.nombre = nombre;
	 
	    }

	    public long getIdPasajero() {
	        return idPasajero;
	    }

	    public String getNombre() {
	        return nombre;
	    }

	 

	    


		public void setNombre(String Nombre) {
			  this.nombre = nombre;
			
		}
		public String toString() {
	        return "ID: " + idPasajero + " | Nombre: " + nombre ;
	    }

		public void setId(long id) {
			  this.idPasajero = id;
		}
}
