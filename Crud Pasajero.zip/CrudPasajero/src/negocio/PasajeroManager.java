package negocio;

import java.util.*;
import Entidad.Pasajero;


public class PasajeroManager {
    private static List<Pasajero> pasajeros = new ArrayList<>();
    

    public void agregarPasajero(Pasajero p) {
        pasajeros.add(p);
    }

    public Pasajero buscarPasajero(long id) {
        return pasajeros.stream().filter(p -> p.getIdPasajero() == id).findFirst().orElse(null);
    }

    public void editarPasajero(long id, String nuevoNombre, long nuevaId) {
    	for (int i = 0; i < pasajeros.size(); i++) {
	        if (pasajeros.get(i).getIdPasajero() == id) {
	           
	           Pasajero actualizado = new Pasajero(nuevaId, nuevoNombre);


	            pasajeros.set(i, actualizado);
	            break;
	        }
	    }
    }

    public void eliminarPasajero(int id) {
        pasajeros.removeIf(p -> p.getIdPasajero() == id);
    }
    public static void mostrarPasajeros(Scanner scanner) {
   	 if (pasajeros.isEmpty()) {
            System.out.println("No hay pasajeros registrados.");
        } else {
            System.out.println("--- Lista de Pasajeros ---");
            for (Pasajero c : pasajeros) {
                System.out.println(c);
   }
        }
   }
	


}
