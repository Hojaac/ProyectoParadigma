package presentacion;

import java.util.Scanner;

import Entidad.Pasajero;
import negocio.PasajeroManager;

public class Presentacion {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	    PasajeroManager pasajeroManager = new PasajeroManager();
        menuPasajeros(scanner, pasajeroManager);
	}
		   public static void menuPasajeros(Scanner scanner, PasajeroManager manager) {
		        int opcion;
		        do {
		            System.out.println("\n--- Menú Pasajeros ---");
		            System.out.println("1. Agregar");
		            System.out.println("2. Buscar");
		            System.out.println("3. Editar Nombre");
		            System.out.println("4. Eliminar");
		            System.out.println("5. Mostrar Lista");
		            System.out.print("Opción: ");
		            opcion = scanner.nextInt();
		            scanner.nextLine();

		           
					switch (opcion) {
		                case 1:
		                	System.out.print("ID (10 dígitos): ");
		                    String input = "";
		                 
		                 	 boolean valido = false;
		                 	 long id = 0;
		                 	   while (!valido) {
		                 	        input = scanner.nextLine();

		                 	        
		                 	        if (input.matches("\\d{10}")) {
		                 	            try {
		                 	           id = Long.parseLong(input);
		                 	                valido = true;
		                 	            } catch (NumberFormatException e) {
		                 	                System.out.println("El número es demasiado grande.");
		                 	            }
		                 	        } else {
		                 	            System.out.println("Por favor ingresa exactamente 10 dígitos numericos:");
		                 	        }
		                 	    }
		                 	 
		                    System.out.print("Nombre: ");
		                    String nombre = scanner.nextLine();
		                    manager.agregarPasajero(new Pasajero(id, nombre));
		                    break;
		                case 2:
		                	 long idBuscar = 0;
		                     valido = false;
		                       while (!valido) {
		                           try {System.out.print("ID a buscar: ");
		                           	  idBuscar = scanner.nextLong();
		                               Pasajero c = manager.buscarPasajero(idBuscar);
		                               if (c != null)
		                                   System.out.println("Nombre: " + c.getNombre());
		                               else
		                                   System.out.println("No encontrado.");
		                               scanner.nextLine(); 
		                               valido = true;
		                           } catch (java.util.InputMismatchException e) {
		                               System.out.println("Por favor ingresa un número válido.");
		                               scanner.nextLine(); 
		                           }
		                       }
		                     break;
		                case 3:
		                	long idActual = 0;
		                    valido = false;
		                     while (!valido) {
		                         try {  System.out.print("ID a buscar: ");
		                         	  idActual = scanner.nextLong();
		                         	  Pasajero pasajero = manager.buscarPasajero(idActual);
		                         	  scanner.nextLine(); 
		                         	 
		                         	  if (pasajero != null) {
		                         		  String nuevoInput;
		                         		  long nuevoId = 0;
		                         		  valido = false;
		                         		  while (!valido) {
		                         		      	 System.out.print("ID (10 dígitos): ");
		                                          nuevoInput = scanner.nextLine();
		                         			  if (!nuevoInput.matches("\\d+")) {
		                                           System.out.println(" No se permiten letras ni caracteres especiales. Solo números.");
		                                       } else if (nuevoInput.length() != 10) {
		                                           System.out.println(" El ID debe tener exactamente 10 dígitos.");
		                                       } else {
		                                           try {
		                                               nuevoId = Long.parseLong(nuevoInput);
		                                               valido = true;
		                                               
		                                           } catch (NumberFormatException e) {
		                                               System.out.println(" El número es demasiado grande para un int.");
		                                               scanner.nextLine(); 
		                                           }
		                                       }
		                                   }
		                         		  
		                         		    System.out.print("Nuevo nombre: ");
		                         		    String nuevoNombre = scanner.nextLine();
		                                     while (nuevoNombre.matches(".*\\d.*")) { 
		                                         System.out.println("El nombre no puede contener números. Ingresa un nombre válido:");
		                                         nuevoNombre = scanner.nextLine();
		                                     }
		                         		   

		                 
		                                  

		                         		    manager.editarPasajero(idActual, nuevoNombre, nuevoId);
		                         	  }
		                         		 else {
		                         		    System.out.println(" No se encontró un conductor con ese ID.");
		                         		}
		                             valido = true;
		                             
		                         
		                         		  } catch (java.util.InputMismatchException e) {
		                             System.out.println("Por favor ingresa un número válido.");
		                             scanner.nextLine(); 
		                         }
		                     }
		               
		                     break;
		                case 4:
		                    System.out.print("ID a eliminar: ");
		                    int idDel = scanner.nextInt();
		                    manager.eliminarPasajero(idDel);
		                    break;
		                case 5:
		                	 PasajeroManager.mostrarPasajeros(scanner);
		                    break;
		             
		                default:
		                    System.out.println("Opción inválida.");
		            }
		        } while (opcion != 5);
		        scanner.close();
		    }

	}


