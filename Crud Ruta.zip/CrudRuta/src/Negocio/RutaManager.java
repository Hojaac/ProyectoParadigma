package Negocio;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


import Entidad.Ruta;


public class RutaManager {
	private static List<Ruta> rutas = new ArrayList<>();
   

    public void agregarRuta(Ruta ruta) {
        rutas.add(ruta);
    }

    public Ruta buscarRuta(String id) {
        return rutas.stream().filter(r -> r.getIdRuta() == id).findFirst().orElse(null);
    }

    public void editarRuta(String id, String nuevoDestino, String nuevaId,double nuevaDistancia) {
    	for (int i = 0; i < rutas.size(); i++) {
	        if (rutas.get(i).getIdRuta().equalsIgnoreCase(id)) {
	           
	           Ruta actualizado = new Ruta(nuevaId, nuevoDestino, nuevaDistancia);


	            rutas.set(i, actualizado);
	            break;
	        }
	    }
    }

    public void eliminarRuta(String id) {
        rutas.removeIf(r -> r.getIdRuta().equalsIgnoreCase(id));
    }

	public static void mostrarRutas(Scanner scanner) {
		 if (rutas.isEmpty()) {
	            System.out.println("No hay Rutas registradas.");
	        } else {
	            System.out.println("--- Lista de Rutas ---");
	            for (Ruta c : rutas) {
	                System.out.println(c);
	   }
	        }
		
	}
}
