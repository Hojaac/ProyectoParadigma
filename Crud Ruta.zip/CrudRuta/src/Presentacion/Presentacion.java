package Presentacion;

import java.util.Scanner;

import Negocio.RutaManager;
import negocio.PasajeroManager;
import Entidad.Ruta;



public class Presentacion {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	    RutaManager rutaManager = new RutaManager();
        menuRutas(scanner, rutaManager);
	}
		public static void menuRutas(Scanner scanner, RutaManager manager) {
	        int opcion;
	        do {
	            System.out.println("\n--- Menú Rutas ---");
	            System.out.println("1. Agregar");
	            System.out.println("2. Buscar");
	            System.out.println("3. Editar Ruta");
	            System.out.println("4. Eliminar");
	            System.out.println("5. Mostrar");
	            System.out.print("Opción: ");
	            opcion = scanner.nextInt();
	            scanner.nextLine();

	            switch (opcion) {
	                case 1:
	                	String idRuta;
	                	boolean valido = false;

	                	do {
	                	    System.out.print("ID (solo letras y números): ");
	                	    idRuta = scanner.nextLine();

	                	    if (idRuta.matches("[a-zA-Z0-9]+")) {
	                	        valido = true;
	                	    } else {
	                	        System.out.println("ID inválido. Intenta de nuevo (solo letras y números).");
	                	    }

	                	} while (!valido);
	                    System.out.print("Destino: ");
	                    String destino = scanner.nextLine();
	            	   
	                    while (destino.matches(".*\\d.*")) { 
	                        System.out.println("El Destino no puede contener números. Ingresa un nombre válido:");
	                        destino = scanner.nextLine();
	                    }
	                  
	                    double distancia = 0;
                		 valido = false;

                		do {
                		    System.out.print("Ingresa la distancia en kilómetros: ");
                		    String input = scanner.nextLine();

                		    try {
                		        distancia = Double.parseDouble(input);
                		        if (distancia >= 0) {
                		            valido = true;
                		        } else {
                		            System.out.println("La distancia no puede ser negativa.");
                		        }
                		    } catch (NumberFormatException e) {
                		        System.out.println("Por favor ingresa solo números. No se permiten letras ni símbolos.");
                		    }
                		} while (!valido);
	                    manager.agregarRuta(new Ruta(idRuta, destino, distancia));
	                    break;
	                case 2:
	                	String idBuscar = "";
	                    valido = false;
	                      while (!valido) {
	                          try {System.out.print("ID a buscar: ");
	                          	  idBuscar = scanner.nextLine();
	                              Ruta c = manager.buscarRuta(idBuscar);
	                              if (c != null)
	                                  System.out.println("Nombre: " + c.getDestino());
	                              else
	                                  System.out.println("No encontrado.");
	                              scanner.nextLine(); 
	                              valido = true;
	                          } catch (java.util.InputMismatchException e) {
	                              System.out.println("Por favor ingresa un número válido.");
	                              scanner.nextLine(); 
	                          }
	                      }
	                    break;
	                case 3:
	                	String idActual;
	                    valido = false;
	                     while (!valido) {
	                         try {  System.out.print("ID a buscar: ");
	                         	  idActual = scanner.nextLine().trim();
	                         	  Ruta ruta = manager.buscarRuta(idActual);
	                         	  
	                         	 
	                         	  if (ruta != null) {
	                         		 String nuevaRuta = "";
	                         		 boolean valido1 = false;

	                         		do {
	                         			
	                         		    System.out.print("ID (solo letras y números): ");
	                         		    nuevaRuta = scanner.nextLine();

	                         		    if (nuevaRuta.matches("[a-zA-Z0-9]+")) {
	                         		        valido1 = true;
	                         		    } else {
	                         		        System.out.println("Ruta inválido. Intenta de nuevo (solo letras y números).");
	                         		    }

	                         		} while (!valido1);;
	                         		  
	                         		    System.out.print("Nuevo destino: ");
	                         		    String nuevoDestino = scanner.nextLine();
	                         		   while (nuevoDestino.matches(".*\\d.*")) {
	                         			    System.out.println("El nombre no puede contener números. Ingresa un nombre válido:");
	                         			    nuevoDestino = scanner.nextLine();
	                         			}

	                         		  System.out.print("Distancia en kilometros: ");
	                         		 double Nuevadistancia = 0;
	                         		 valido = false;

	                         		do {
	                         		    System.out.print("Ingresa la distancia en kilómetros: ");
	                         		    String input = scanner.nextLine();

	                         		    try {
	                         		        Nuevadistancia = Double.parseDouble(input);
	                         		        if (Nuevadistancia >= 0) {
	                         		            valido = true;
	                         		        } else {
	                         		            System.out.println("La distancia no puede ser negativa.");
	                         		        }
	                         		    } catch (NumberFormatException e) {
	                         		        System.out.println("Por favor ingresa solo números. No se permiten letras ni símbolos.");
	                         		    }
	                         		} while (!valido);
	                                  

	                         		   
										manager.editarRuta(idActual, nuevaRuta, nuevoDestino, Nuevadistancia);
	                         	  }
	                         		 else {
	                         		    System.out.println(" No se encontró un conductor con ese ID.");
	                         		}
	                             valido = true;
	                             
	                         
	                         		  } catch (java.util.InputMismatchException e) {
	                             System.out.println("Por favor ingresa un número válido.");
	                             scanner.nextLine(); 
	                         }
	                     }
	               
	                   
	                    break;
	                case 4:
	                	System.out.print("ID a eliminar: ");
	                   String idDel = scanner.nextLine();
	                    manager.eliminarRuta(idDel);
	               
	                    break;
	                case 5:
	                	RutaManager.mostrarRutas(scanner);
	                    break;
	                default:
	                    System.out.println("Opción inválida.");
	            }
	        } while (opcion != 5);
	    }
	
}

