package co.edu.poligran.paradigmas.colections.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Presentación {

	public static void main(String[] args) {
		Scanner sc =  new Scanner(System.in);
		String[] daysOfWeek = new String[7];
		daysOfWeek[0] = "Domingo";
		daysOfWeek[1] = "Lunes";
		daysOfWeek[2] = "Martes";
		daysOfWeek[3] = "Miercoles";
		daysOfWeek[4] = "Jueves";
		daysOfWeek[5] = "Viernes";
		daysOfWeek[6] = "Sabado";
		
		for(int i = 0; i < daysOfWeek.length; i++) {
			int indice = i+1;
			System.out.println("El dia de la semana en la posición i= "+indice+" es: "+daysOfWeek[i]);
		}
		
		for(int i = 0; i < daysOfWeek.length; i++) {
			if(daysOfWeek[i].contains("Martes")) {
				System.out.println("Se encontró el objeto");
			}
			
		}
		
		
		List<String> diasDeLaSemana = new ArrayList<String>(); 
		
		diasDeLaSemana.add("domingo");
		diasDeLaSemana.add("lunes");
		
		boolean continuar = false;
		do {
			System.out.println("agregue el dia de la semana");
			diasDeLaSemana.add(sc.next());
			System.out.println("Quiere continuar? digite S/N");
			String opcion = sc.next();
		if(opcion.contains("S")) {
			continuar = true;
		}else {
			continuar = false;
		}
		sc.nextLine();
		}while(continuar);
		
		for(String cad : diasDeLaSemana) {
			System.out.println(cad);
		}
		
		System.out.println("digite el dia que quiere modificar");
		String diaMod = sc.next();
		
		int indice = diasDeLaSemana.indexOf(diaMod);
		System.out.println("digite el valor a cambiar");
		diasDeLaSemana.set(indice, sc.next());
		
		for(String cad : diasDeLaSemana) {
			System.out.println(cad);
		}
		
		System.out.println("Digite el día que quiere remover");
		String diaRem = sc.next();
		int iRem = diasDeLaSemana.indexOf(diaRem);
		diasDeLaSemana.remove(iRem);
		
		System.out.println("La lsita con los valores removidos es ");
		for(String cad : diasDeLaSemana) {
			System.out.println(cad);
		}
//		System.out.println("El valor del día de la semana en la posición 8 es "+daysOfWeek[8]);

	}

}
