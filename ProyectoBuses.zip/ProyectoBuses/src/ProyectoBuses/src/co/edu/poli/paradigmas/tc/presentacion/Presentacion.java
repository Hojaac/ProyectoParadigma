package ProyectoBuses.src.co.edu.poli.paradigmas.tc.presentacion;




import java.util.Scanner;

import co.edu.poli.paradigmas.tc.entities.Conductor;
import co.edu.poli.paradigmas.tc.entities.Pasajero;

import co.edu.poli.paradigmas.tc.entities.Ruta;
import co.edu.poli.paradigmas.tc.negocio.ConductorManager;
import co.edu.poli.paradigmas.tc.negocio.PasajeroManager;

import co.edu.poli.paradigmas.tc.negocio.RutaManager;


public class Presentacion {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        ConductorManager conductorManager = new ConductorManager();
        PasajeroManager pasajeroManager = new PasajeroManager();
        RutaManager rutaManager = new RutaManager();

        int opcion = 0;

        do {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("1. Gestionar Conductores");
            System.out.println("2. Gestionar Pasajeros");
            System.out.println("3. Gestionar Rutas");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    menuConductores(scanner, conductorManager);
                    break;
                case 2:
                    menuPasajeros(scanner, pasajeroManager);
                    break;
                case 3:
                    menuRutas(scanner, rutaManager);
                    break;
                case 4:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 4);

        scanner.close();
    }


    public static void menuConductores(Scanner scanner, ConductorManager manager) {
    	 System.out.println("\n--- Menú Conductores ---");
         System.out.println("1. Agregar");
         System.out.println("2. Buscar");
         System.out.println("3. Editar Licencia");
         System.out.println("4. Eliminar");
         System.out.println("5. Volver");
         System.out.print("Opción: ");
        int opcion = 0;
        boolean valido = false;
        while (!valido) {
        do { 
        	try {
        
            opcion = scanner.nextInt();
            scanner.nextLine(); 
            valido = true;
        } catch (java.util.InputMismatchException e) {
            System.out.println("Por favor ingresa un número válido.");
            scanner.nextLine(); 
        }
           
         

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = 0;
                    valido = false;
                    while (!valido) {
                        try {
                            id = scanner.nextInt();
                            scanner.nextLine(); 
                            valido = true;
                        } catch (java.util.InputMismatchException e) {
                            System.out.println("Por favor ingresa un número válido.");
                            scanner.nextLine(); 
                        }
                    }
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    while (nombre.matches(".*\\d.*")) { 
                        System.out.println("El nombre no puede contener números. Ingresa un nombre válido:");
                        nombre = scanner.nextLine();
                    }
                    System.out.print("Categoria Licencia: ");
                    String licencia = scanner.nextLine();
                    manager.agregarConductor(new Conductor(id, nombre, licencia));
                    break;
                case 2:
                    System.out.print("ID a buscar: ");
               
                     int idBuscar = 0;
                  valido = false;
                    while (!valido) {
                        try {
                        	  idBuscar = scanner.nextInt();
                            Conductor c = manager.buscarConductor(idBuscar);
                            if (c != null)
                                System.out.println("Nombre: " + c.getNombre() + ", Licencia: " + c.getLicencia());
                            else
                                System.out.println("No encontrado.");
                            scanner.nextLine(); 
                            valido = true;
                        } catch (java.util.InputMismatchException e) {
                            System.out.println("Por favor ingresa un número válido.");
                            scanner.nextLine(); 
                        }
                    }
                  
                  
                    break;
                case 3:
                    System.out.print("ID a editar: ");
                    int idEdit = 0;
                    valido = false;
                    while (!valido) {
                        try {
                        	  idEdit = scanner.nextInt();
                       
                        
                            valido = true;
                        } catch (java.util.InputMismatchException e) {
                            System.out.println("Por favor ingresa un número válido.");
                            scanner.nextLine(); 
                        }
                    }
                    scanner.nextLine();
                    System.out.print("Nueva licencia: ");
                    String nuevaLic = scanner.nextLine();
                    manager.editarLicencia(idEdit, nuevaLic);
                    break;
                case 4:
                    System.out.print("ID a eliminar: ");
                    int idDel = scanner.nextInt();
                    manager.eliminarConductor(idDel);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 5);
    }
    }
    public static void menuPasajeros(Scanner scanner, PasajeroManager manager) {
        int opcion;
        do {
            System.out.println("\n--- Menú Pasajeros ---");
            System.out.println("1. Agregar");
            System.out.println("2. Buscar");
            System.out.println("3. Editar Nombre");
            System.out.println("4. Eliminar");
            System.out.println("5. Volver");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    manager.agregarPasajero(new Pasajero(id, nombre));
                    break;
                case 2:
                    System.out.print("ID a buscar: ");
                    int idBuscar = scanner.nextInt();
                    Pasajero p = manager.buscarPasajero(idBuscar);
                    if (p != null)
                        System.out.println("Nombre: " + p.getNombre());
                    else
                        System.out.println("No encontrado.");
                    break;
                case 3:
                    System.out.print("ID a editar: ");
                    int idEdit = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = scanner.nextLine();
                    manager.editarNombrePasajero(idEdit, nuevoNombre);
                    break;
                case 4:
                    System.out.print("ID a eliminar: ");
                    int idDel = scanner.nextInt();
                    manager.eliminarPasajero(idDel);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 5);
    }

    public static void menuRutas(Scanner scanner, RutaManager manager) {
        int opcion;
        do {
            System.out.println("\n--- Menú Rutas ---");
            System.out.println("1. Agregar");
            System.out.println("2. Buscar");
            System.out.println("3. Editar Ruta");
            System.out.println("4. Eliminar");
            System.out.println("5. Volver");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Destino: ");
                    String destino = scanner.nextLine();
                    System.out.print("Distancia: ");
                    double distancia = scanner.nextDouble();
                    manager.agregarRuta(new Ruta(id, destino, distancia));
                    break;
                case 2:
                    System.out.print("ID a buscar: ");
                    int idBuscar = scanner.nextInt();
                    Ruta r = manager.buscarRuta(idBuscar);
                    if (r != null)
                        System.out.println("Destino: " + r.getDestino() + ", Distancia: " + r.getDistancia());
                    else
                        System.out.println("No encontrada.");
                    break;
                case 3:
                    System.out.print("ID a editar: ");
                    int idEdit = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nuevo destino: ");
                    String nuevoDestino = scanner.nextLine();
                    System.out.print("Nueva distancia: ");
                    double nuevaDistancia = scanner.nextDouble();
                    manager.actualizarRuta(idEdit, nuevoDestino, nuevaDistancia);
                    break;
                case 4:
                    System.out.print("ID a eliminar: ");
                    int idDel = scanner.nextInt();
                    manager.eliminarRuta(idDel);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 5);
    }
}
