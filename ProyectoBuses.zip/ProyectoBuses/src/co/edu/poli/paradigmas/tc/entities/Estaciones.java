package co.edu.poli.paradigmas.tc.entities;

public class Estaciones {
    private int idEstaciones;
    private String nombre;
    private int orden;
    private int idRuta;
	public int getIdRuta() {
	
		return 0;
	}

	  

	    public int getOrden() {
	        return orden;
	    }
	
    // Constructor, Getters, Setters
}
	
