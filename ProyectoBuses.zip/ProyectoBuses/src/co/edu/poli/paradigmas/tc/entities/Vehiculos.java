package co.edu.poli.paradigmas.tc.entities;
public class Vehiculos {
    private String placa;
    private String modelo;
    private int capacidad;
    private String estado;
	public Object getPlaca() {
		
		return null;
	}
	public void setEstado(String nuevoEstado) {
		
		
	}

   
}
